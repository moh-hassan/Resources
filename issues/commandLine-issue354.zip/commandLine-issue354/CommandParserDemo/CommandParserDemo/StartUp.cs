﻿using System;
using System.Collections.Generic;
using System.Text;
using CommandLine.Text;

namespace CommandParserDemo
{
    public class StartUp
    {
        public static string _copyRight= CopyrightInfo. Default;
    }
}
