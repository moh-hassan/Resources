﻿using System;

namespace CommandParserDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(StartUp._copyRight);
        }
    }
}
