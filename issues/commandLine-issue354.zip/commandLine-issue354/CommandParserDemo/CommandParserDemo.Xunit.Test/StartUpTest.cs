﻿using CommandLine.Text;
using Xunit;

namespace CommandParserDemo.Xunit.Test
{
   public  class StartUpTest
    {
        [Fact]
        public void Test1()
        {
            //Console.WriteLine(StartUp._copyRight);
            var copyRight = StartUp._copyRight;
        }
        [Fact]
        public void Test2()
        {
            //Console.WriteLine(StartUp._copyRight);
            var copyRight = CopyrightInfo.Default;

        }
    }
}
