﻿using System;
using CommandLine.Text;
using NUnit.Framework;

namespace CommandParserDemo.Test
{
   public  class StartUpTest
    {
        [Test]
        public  void Test1()
        {
            //Console.WriteLine(StartUp._copyRight);
            var copyRight=StartUp._copyRight;
        }
        [Test]
        public void Test2()
        {
            //Console.WriteLine(StartUp._copyRight);
            var copyRight = CopyrightInfo.Default;

        }

         
    }
}
